﻿using System;

namespace $safeprojectname$
{
    class Program
    {
        //FUArchitecture Console
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
